// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Cast jasperware relief\n", stdout);
  return lionss_run_workload("jasperware");
}
