// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Spread mossrock cover\n", stdout);
  return lionss_run_workload("mossrock");
}
