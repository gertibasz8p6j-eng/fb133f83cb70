// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Inline across modules"); }
int main(){
  announce();
  return lionss_run_workload("ocaml-flambda");
}
