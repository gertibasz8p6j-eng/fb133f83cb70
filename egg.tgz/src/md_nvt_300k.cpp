// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Run NVT ensemble\n", stdout);
  return lionss_run_workload("md_nvt_300k");
}
