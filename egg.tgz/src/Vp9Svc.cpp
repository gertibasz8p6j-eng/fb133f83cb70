// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode VP9 SVC layers\n", stdout);
  return lionss_run_workload("Vp9Svc");
}
